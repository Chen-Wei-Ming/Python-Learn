def test_disfunction():
    print('success')
